from __future__ import annotations

import sqlite3
from pathlib import Path

DATABASE_PATH = Path("database") / "polymarket.db"
CONSUMER_NAME = "institutional_review_engine_v1"


def object_exists(connection: sqlite3.Connection, object_type: str, name: str) -> bool:
    return connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type = ? AND name = ?",
        (object_type, name),
    ).fetchone() is not None


def main() -> None:
    if not DATABASE_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DATABASE_PATH}")

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row

    print("=" * 78)
    print("INSTITUTIONAL REVIEW HEALTH")
    print("=" * 78)

    healthy = True
    for table in [
        "institutional_reviews",
        "platform_events",
        "event_consumers",
        "event_consumer_receipts",
    ]:
        present = object_exists(connection, "table", table)
        healthy = healthy and present
        print(f"{table}: {'OK' if present else 'MISSING'}")

    view_present = object_exists(connection, "view", "current_institutional_reviews")
    healthy = healthy and view_present
    print(f"current_institutional_reviews: {'OK' if view_present else 'MISSING'}")

    if not object_exists(connection, "table", "institutional_reviews"):
        print("Overall status: ATTENTION REQUIRED")
        print("=" * 78)
        connection.close()
        raise SystemExit(1)

    totals = connection.execute(
        """
        SELECT
            COUNT(*) AS total_reviews,
            SUM(CASE WHEN review_status = 'COMPLETED' THEN 1 ELSE 0 END) AS completed_reviews,
            COUNT(DISTINCT opportunity_id) AS reviewed_opportunities,
            MAX(review_timestamp) AS latest_review
        FROM institutional_reviews
        """
    ).fetchone()

    reviewed_events = connection.execute(
        """
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) AS pending
        FROM platform_events
        WHERE event_type = 'OpportunityReviewed'
        """
    ).fetchone()

    duplicate_fingerprints = connection.execute(
        """
        SELECT COUNT(*) AS total
        FROM (
            SELECT review_fingerprint
            FROM institutional_reviews
            GROUP BY review_fingerprint
            HAVING COUNT(*) > 1
        )
        """
    ).fetchone()["total"]

    consumer = connection.execute(
        """
        SELECT consumer_name, last_success_at, last_error
        FROM event_consumers
        WHERE consumer_name = ?
        """,
        (CONSUMER_NAME,),
    ).fetchone()

    print(f"Total reviews: {totals['total_reviews'] or 0}")
    print(f"Completed reviews: {totals['completed_reviews'] or 0}")
    print(f"Distinct reviewed opportunities: {totals['reviewed_opportunities'] or 0}")
    print(f"OpportunityReviewed events: {reviewed_events['total'] or 0}")
    print(f"Pending OpportunityReviewed events: {reviewed_events['pending'] or 0}")
    print(f"Duplicate review fingerprints: {duplicate_fingerprints}")
    print(f"Latest review: {totals['latest_review']}")

    if consumer:
        print(f"Consumer registered: {consumer['consumer_name']}")
        print(f"Last successful run: {consumer['last_success_at']}")
        print(f"Last error: {consumer['last_error']}")
        healthy = healthy and not consumer["last_error"]
    else:
        print("Consumer registered: NO")
        healthy = False

    healthy = healthy and duplicate_fingerprints == 0
    print(f"Overall status: {'HEALTHY' if healthy else 'ATTENTION REQUIRED'}")
    print("=" * 78)

    connection.close()
    if not healthy:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
