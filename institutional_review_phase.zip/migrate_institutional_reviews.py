from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

ROOT = Path.cwd()
DB_PATH = ROOT / "database" / "polymarket.db"
BACKUP_DIR = ROOT / "database" / "backups"


def main() -> None:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"polymarket_before_institutional_reviews_{stamp}.db"
    shutil.copy2(DB_PATH, backup_path)

    connection = sqlite3.connect(DB_PATH)
    try:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS institutional_reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                review_id TEXT NOT NULL UNIQUE,
                opportunity_id TEXT NOT NULL,
                market_id TEXT,
                source_event_id TEXT NOT NULL,
                review_timestamp TEXT NOT NULL,
                review_status TEXT NOT NULL,
                opportunity_score REAL,
                opportunity_grade TEXT,
                opportunity_decision TEXT,
                confidence_score REAL NOT NULL,
                confidence_label TEXT NOT NULL,
                consensus_strength TEXT NOT NULL,
                capital_strength TEXT NOT NULL,
                wallet_quality TEXT NOT NULL,
                timing_grade TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                recommendation TEXT NOT NULL,
                summary TEXT NOT NULL,
                strengths_json TEXT NOT NULL,
                risks_json TEXT NOT NULL,
                reasoning_json TEXT NOT NULL,
                metrics_json TEXT NOT NULL,
                review_fingerprint TEXT NOT NULL UNIQUE,
                engine_version TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_institutional_reviews_opportunity
                ON institutional_reviews(opportunity_id, review_timestamp DESC);

            CREATE INDEX IF NOT EXISTS idx_institutional_reviews_market
                ON institutional_reviews(market_id, review_timestamp DESC);

            CREATE INDEX IF NOT EXISTS idx_institutional_reviews_recommendation
                ON institutional_reviews(recommendation, confidence_score DESC);

            CREATE INDEX IF NOT EXISTS idx_institutional_reviews_source_event
                ON institutional_reviews(source_event_id);

            DROP VIEW IF EXISTS current_institutional_reviews;

            CREATE VIEW current_institutional_reviews AS
            SELECT reviews.*
            FROM institutional_reviews AS reviews
            INNER JOIN (
                SELECT opportunity_id, MAX(id) AS latest_id
                FROM institutional_reviews
                GROUP BY opportunity_id
            ) AS latest
                ON latest.latest_id = reviews.id;
            """
        )
        connection.commit()
        print("=" * 78)
        print("INSTITUTIONAL REVIEW MIGRATION COMPLETE")
        print("=" * 78)
        print(f"Backup: {backup_path}")
        print("Table: institutional_reviews")
        print("View: current_institutional_reviews")
        print("Run next:")
        print("  python src/institutional_review_engine.py")
        print("  python src/institutional_review_health.py")
        print("=" * 78)
    except Exception:
        connection.rollback()
        print(f"Migration failed. Backup preserved at: {backup_path}")
        raise
    finally:
        connection.close()


if __name__ == "__main__":
    main()
