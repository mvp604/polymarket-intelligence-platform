from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DATABASE_PATH = Path("database") / "polymarket.db"
SOURCE_TABLE = "opportunity_intelligence_v2"
CONSUMER_NAME = "institutional_review_engine_v1"
ENGINE_VERSION = "1.0.0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize(value: Any) -> str:
    return str(value or "").strip().upper()


def safe_float(value: Any) -> float:
    try:
        return float(value) if value is not None else 0.0
    except (TypeError, ValueError):
        return 0.0


def safe_int(value: Any) -> int:
    try:
        return int(value) if value is not None else 0
    except (TypeError, ValueError):
        return 0


def first_value(data: dict[str, Any], names: list[str]) -> Any:
    lowered = {str(key).lower(): value for key, value in data.items()}
    for name in names:
        value = lowered.get(name.lower())
        if value is not None:
            return value
    return None


def load_opportunity(connection: sqlite3.Connection, opportunity_id: str) -> dict[str, Any]:
    columns = {
        row["name"]
        for row in connection.execute(
            f'PRAGMA table_info("{SOURCE_TABLE}")'
        ).fetchall()
    }
    if "opportunity_id" not in columns:
        return {}

    row = connection.execute(
        f'''SELECT * FROM "{SOURCE_TABLE}"
            WHERE CAST(opportunity_id AS TEXT) = ? LIMIT 1''',
        (opportunity_id,),
    ).fetchone()
    return dict(row) if row else {}


def derive_metrics(data: dict[str, Any]) -> dict[str, Any]:
    return {
        "score": round(safe_float(first_value(data, ["score", "opportunity_score", "conviction_score"])), 2),
        "grade": normalize(first_value(data, ["grade", "opportunity_grade", "confidence_grade"])),
        "decision": normalize(first_value(data, ["decision", "recommended_action", "action"])),
        "timing": normalize(first_value(data, ["timing", "timing_label", "timing_classification"])),
        "wallet_count": safe_int(first_value(data, ["wallet_count", "matching_wallets", "agreeing_wallets"])),
        "elite_wallet_count": safe_int(first_value(data, ["elite_wallet_count", "elite_count", "top_wallet_count"])),
        "capital": round(safe_float(first_value(data, ["combined_value", "capital", "total_capital", "combined_capital", "current_value", "position_value"])), 2),
        "market_id": str(first_value(data, ["market_id", "condition_id", "token_id"]) or ""),
        "title": str(first_value(data, ["title", "market_title", "question"]) or ""),
        "outcome": str(first_value(data, ["outcome", "side"]) or ""),
    }


def should_review(metrics: dict[str, Any]) -> bool:
    decision = metrics["decision"]
    if decision in {"ACTIONABLE", "ALERT", "PLAY", "BET", "MONITOR", "WATCHLIST"}:
        return True
    if decision == "PASS":
        return False
    return metrics["score"] >= 70.0


def calculate_confidence(metrics: dict[str, Any]) -> tuple[float, str]:
    confidence = metrics["score"] * 0.70
    confidence += min(metrics["wallet_count"], 6) * 2.0
    confidence += min(metrics["elite_wallet_count"], 3) * 4.0

    capital = metrics["capital"]
    confidence += 8 if capital >= 1_000_000 else 6 if capital >= 250_000 else 4 if capital >= 50_000 else 2 if capital >= 10_000 else 0

    timing = metrics["timing"]
    if timing in {"EARLY", "OPEN", "FAVORABLE"}:
        confidence += 6
    elif timing in {"COORDINATED", "STABLE"}:
        confidence += 4
    elif timing == "TIGHT":
        confidence -= 2
    elif timing in {"LATE", "CLOSED", "UNFAVORABLE"}:
        confidence -= 8

    decision = metrics["decision"]
    if decision in {"ACTIONABLE", "ALERT", "PLAY", "BET"}:
        confidence += 8
    elif decision in {"MONITOR", "WATCHLIST"}:
        confidence += 3
    elif decision == "PASS":
        confidence -= 10

    confidence = round(max(0.0, min(100.0, confidence)), 2)
    label = "VERY_HIGH" if confidence >= 85 else "HIGH" if confidence >= 75 else "MODERATE" if confidence >= 60 else "LOW" if confidence >= 45 else "VERY_LOW"
    return confidence, label


def classify_strengths(metrics: dict[str, Any]) -> dict[str, str]:
    wallets = metrics["wallet_count"]
    consensus = "VERY_STRONG" if wallets >= 5 else "STRONG" if wallets >= 4 else "MODERATE" if wallets >= 2 else "WEAK"

    capital = metrics["capital"]
    capital_strength = "VERY_STRONG" if capital >= 1_000_000 else "STRONG" if capital >= 250_000 else "MODERATE" if capital >= 50_000 else "WEAK"

    elites = metrics["elite_wallet_count"]
    wallet_quality = "VERY_STRONG" if elites >= 2 else "STRONG" if elites == 1 else "UNCONFIRMED"

    timing = metrics["timing"]
    timing_grade = "FAVORABLE" if timing in {"EARLY", "OPEN", "FAVORABLE"} else "ACCEPTABLE" if timing in {"COORDINATED", "STABLE"} else "CONSTRAINED" if timing == "TIGHT" else "UNFAVORABLE" if timing in {"LATE", "CLOSED", "UNFAVORABLE"} else "UNKNOWN"

    return {
        "consensus_strength": consensus,
        "capital_strength": capital_strength,
        "wallet_quality": wallet_quality,
        "timing_grade": timing_grade,
    }


def determine_risk(metrics: dict[str, Any], strengths: dict[str, str]) -> tuple[str, list[str]]:
    risks: list[str] = []
    if metrics["wallet_count"] < 3:
        risks.append("Limited wallet agreement")
    if metrics["elite_wallet_count"] == 0:
        risks.append("No confirmed elite-wallet participation")
    if metrics["capital"] < 50_000:
        risks.append("Capital support is limited")
    if strengths["timing_grade"] == "CONSTRAINED":
        risks.append("Entry timing is tight")
    elif strengths["timing_grade"] == "UNFAVORABLE":
        risks.append("Entry timing is unfavorable")
    elif strengths["timing_grade"] == "UNKNOWN":
        risks.append("Timing evidence is incomplete")

    level = "HIGH" if len(risks) >= 4 else "MEDIUM" if len(risks) >= 2 else "LOW"
    return level, risks


def recommendation_for(metrics: dict[str, Any]) -> str:
    if metrics["decision"] in {"ACTIONABLE", "ALERT", "PLAY", "BET"}:
        return "REVIEW_FOR_ALERT"
    if metrics["decision"] in {"MONITOR", "WATCHLIST"}:
        return "CONTINUE_MONITORING"
    return "NO_ACTION"


def make_fingerprint(opportunity_id: str, event_id: str, metrics: dict[str, Any]) -> str:
    raw = json.dumps(
        {"opportunity_id": opportunity_id, "event_id": event_id, "metrics": metrics, "engine_version": ENGINE_VERSION},
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def publish_review_event(connection: sqlite3.Connection, review: dict[str, Any]) -> bool:
    cursor = connection.execute(
        """
        INSERT OR IGNORE INTO platform_events (
            event_id, event_type, source_engine, source_version,
            aggregate_type, aggregate_id, payload_json, occurred_at,
            correlation_id, causation_id, deduplication_key, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            str(uuid.uuid4()), "OpportunityReviewed", CONSUMER_NAME, ENGINE_VERSION,
            "institutional_review", review["review_id"],
            json.dumps(review["event_payload"], sort_keys=True), utc_now(),
            review["source_event_id"], review["source_event_id"],
            f"OpportunityReviewed:{review['fingerprint']}", "PENDING",
        ),
    )
    return cursor.rowcount == 1


def main() -> None:
    if not DATABASE_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DATABASE_PATH}")

    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")

    connection.execute(
        """
        INSERT INTO event_consumers (consumer_name, description)
        VALUES (?, ?)
        ON CONFLICT(consumer_name) DO UPDATE SET
            description = excluded.description,
            updated_at = CURRENT_TIMESTAMP
        """,
        (CONSUMER_NAME, "Creates deterministic institutional reviews for meaningful opportunities."),
    )

    events = connection.execute(
        """
        SELECT e.event_id, e.aggregate_id, e.payload_json
        FROM platform_events AS e
        LEFT JOIN event_consumer_receipts AS r
          ON r.event_id = e.event_id AND r.consumer_name = ?
        WHERE e.event_type IN ('OpportunityCreated', 'OpportunityUpdated')
          AND r.id IS NULL
        ORDER BY e.id ASC
        """,
        (CONSUMER_NAME,),
    ).fetchall()

    created = skipped = published = 0

    for event in events:
        payload = json.loads(event["payload_json"])
        opportunity_id = str(payload.get("opportunity_id") or event["aggregate_id"])
        data = load_opportunity(connection, opportunity_id)
        data.update({key: value for key, value in payload.items() if value is not None})
        metrics = derive_metrics(data)

        if not should_review(metrics):
            connection.execute(
                "INSERT OR IGNORE INTO event_consumer_receipts (consumer_name, event_id, result_json) VALUES (?, ?, ?)",
                (CONSUMER_NAME, event["event_id"], json.dumps({"status": "SKIPPED", "decision": metrics["decision"], "score": metrics["score"]}, sort_keys=True)),
            )
            skipped += 1
            continue

        confidence_score, confidence_label = calculate_confidence(metrics)
        strengths = classify_strengths(metrics)
        risk_level, risks = determine_risk(metrics, strengths)
        recommendation = recommendation_for(metrics)
        reasoning = [
            f"Opportunity score is {metrics['score']:.2f}.",
            f"{metrics['wallet_count']} wallets support the outcome.",
            f"{metrics['elite_wallet_count']} elite wallets are represented.",
            f"Observed supporting capital is ${metrics['capital']:,.2f}.",
            f"Consensus strength is {strengths['consensus_strength']}.",
            f"Wallet quality is {strengths['wallet_quality']}.",
            f"Timing is {strengths['timing_grade']}.",
        ] + [f"Risk: {risk}." for risk in risks]

        market_name = metrics["title"] or metrics["market_id"] or "Unknown market"
        outcome_name = metrics["outcome"] or "Unknown outcome"
        summary = f"{market_name} | {outcome_name}: score {metrics['score']:.2f}, institutional confidence {confidence_label}, recommendation {recommendation}."

        review_id = str(uuid.uuid4())
        fingerprint = make_fingerprint(opportunity_id, event["event_id"], metrics)

        cursor = connection.execute(
            """
            INSERT OR IGNORE INTO institutional_reviews (
                review_id, opportunity_id, market_id, source_event_id,
                review_timestamp, review_status, opportunity_score,
                opportunity_grade, opportunity_decision, confidence_score,
                confidence_label, consensus_strength, capital_strength,
                wallet_quality, timing_grade, risk_level, recommendation,
                summary, strengths_json, risks_json, reasoning_json,
                metrics_json, review_fingerprint, engine_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                review_id, opportunity_id, metrics["market_id"], event["event_id"],
                utc_now(), "COMPLETED", metrics["score"], metrics["grade"],
                metrics["decision"], confidence_score, confidence_label,
                strengths["consensus_strength"], strengths["capital_strength"],
                strengths["wallet_quality"], strengths["timing_grade"],
                risk_level, recommendation, summary,
                json.dumps(strengths, sort_keys=True), json.dumps(risks, sort_keys=True),
                json.dumps(reasoning, sort_keys=True), json.dumps(metrics, sort_keys=True),
                fingerprint, ENGINE_VERSION,
            ),
        )

        if cursor.rowcount == 1:
            created += 1
            review = {
                "review_id": review_id,
                "source_event_id": event["event_id"],
                "fingerprint": fingerprint,
                "event_payload": {
                    "review_id": review_id,
                    "opportunity_id": opportunity_id,
                    "market_id": metrics["market_id"],
                    "source_event_id": event["event_id"],
                    "confidence_score": confidence_score,
                    "confidence_label": confidence_label,
                    "risk_level": risk_level,
                    "recommendation": recommendation,
                    "summary": summary,
                },
            }
            if publish_review_event(connection, review):
                published += 1

        connection.execute(
            "INSERT OR IGNORE INTO event_consumer_receipts (consumer_name, event_id, result_json) VALUES (?, ?, ?)",
            (CONSUMER_NAME, event["event_id"], json.dumps({"status": "REVIEWED", "review_id": review_id, "confidence_score": confidence_score, "confidence_label": confidence_label, "risk_level": risk_level, "recommendation": recommendation}, sort_keys=True)),
        )

    connection.execute(
        """
        UPDATE event_consumers
        SET last_run_at = CURRENT_TIMESTAMP,
            last_success_at = CURRENT_TIMESTAMP,
            last_error = NULL,
            updated_at = CURRENT_TIMESTAMP
        WHERE consumer_name = ?
        """,
        (CONSUMER_NAME,),
    )
    connection.commit()

    totals = connection.execute(
        "SELECT recommendation, COUNT(*) AS total FROM institutional_reviews GROUP BY recommendation ORDER BY recommendation"
    ).fetchall()

    print("=" * 78)
    print("INSTITUTIONAL REVIEW ENGINE")
    print("=" * 78)
    print(f"Source events examined: {len(events):,}")
    print(f"New reviews created: {created:,}")
    print(f"Non-meaningful events skipped: {skipped:,}")
    print(f"OpportunityReviewed events published: {published:,}")
    print("Stored review totals:")
    for row in totals:
        print(f"  {row['recommendation']}: {row['total']}")
    print("=" * 78)
    connection.close()


if __name__ == "__main__":
    main()
