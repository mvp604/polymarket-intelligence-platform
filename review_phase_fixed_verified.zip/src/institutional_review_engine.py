from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DB_PATH = Path("database") / "polymarket.db"
CONSUMER_NAME = "institutional_review_engine_v1"
ENGINE_VERSION = "1.0.0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize(value: Any) -> str:
    return str(value or "").strip().upper()


def as_float(value: Any) -> float:
    try:
        return float(value) if value is not None else 0.0
    except (TypeError, ValueError):
        return 0.0


def as_int(value: Any) -> int:
    try:
        return int(value) if value is not None else 0
    except (TypeError, ValueError):
        return 0


def pick(data: dict[str, Any], *names: str) -> Any:
    lowered = {str(k).lower(): v for k, v in data.items()}
    for name in names:
        value = lowered.get(name.lower())
        if value is not None:
            return value
    return None


def metrics_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "opportunity_id": str(pick(payload, "opportunity_id") or ""),
        "market_id": str(pick(payload, "market_id") or ""),
        "title": str(pick(payload, "title", "market_title", "question") or ""),
        "outcome": str(pick(payload, "outcome", "side") or ""),
        "score": round(as_float(pick(payload, "score", "opportunity_score")), 2),
        "grade": normalize(pick(payload, "grade", "opportunity_grade")),
        "decision": normalize(pick(payload, "decision", "recommended_action")),
        "wallet_count": as_int(pick(payload, "wallet_count", "matching_wallets")),
        "elite_wallet_count": as_int(pick(payload, "elite_wallet_count", "elite_count")),
        "capital": round(as_float(pick(payload, "combined_value", "capital", "current_value")), 2),
    }


def should_review(metrics: dict[str, Any]) -> bool:
    decision = metrics["decision"]
    if decision in {"MONITOR", "WATCHLIST", "ACTIONABLE", "ALERT", "PLAY", "BET"}:
        return True
    if decision == "PASS":
        return False
    return metrics["score"] >= 70.0


def confidence(metrics: dict[str, Any]) -> tuple[float, str]:
    value = metrics["score"] * 0.75
    value += min(metrics["wallet_count"], 6) * 2
    value += min(metrics["elite_wallet_count"], 3) * 4

    if metrics["capital"] >= 1_000_000:
        value += 8
    elif metrics["capital"] >= 250_000:
        value += 6
    elif metrics["capital"] >= 50_000:
        value += 4

    if metrics["decision"] in {"ACTIONABLE", "ALERT", "PLAY", "BET"}:
        value += 8
    elif metrics["decision"] in {"MONITOR", "WATCHLIST"}:
        value += 3

    value = round(max(0.0, min(100.0, value)), 2)
    if value >= 85:
        label = "VERY_HIGH"
    elif value >= 75:
        label = "HIGH"
    elif value >= 60:
        label = "MODERATE"
    elif value >= 45:
        label = "LOW"
    else:
        label = "VERY_LOW"
    return value, label


def risk(metrics: dict[str, Any]) -> tuple[str, list[str]]:
    reasons: list[str] = []
    if metrics["wallet_count"] < 3:
        reasons.append("Limited wallet agreement")
    if metrics["elite_wallet_count"] == 0:
        reasons.append("No confirmed elite-wallet participation")
    if metrics["capital"] < 50_000:
        reasons.append("Capital support is limited")

    if len(reasons) >= 3:
        return "HIGH", reasons
    if len(reasons) >= 1:
        return "MEDIUM", reasons
    return "LOW", reasons


def recommendation(decision: str) -> str:
    if decision in {"ACTIONABLE", "ALERT", "PLAY", "BET"}:
        return "REVIEW_FOR_ALERT"
    if decision in {"MONITOR", "WATCHLIST"}:
        return "CONTINUE_MONITORING"
    return "NO_ACTION"


def fingerprint(event_id: str, metrics: dict[str, Any]) -> str:
    raw = json.dumps(
        {"event_id": event_id, "metrics": metrics, "version": ENGINE_VERSION},
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def main() -> None:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row

    connection.execute(
        """
        INSERT INTO event_consumers (consumer_name, description)
        VALUES (?, ?)
        ON CONFLICT(consumer_name) DO UPDATE SET
            description = excluded.description,
            updated_at = CURRENT_TIMESTAMP
        """,
        (CONSUMER_NAME, "Creates deterministic institutional reviews."),
    )

    events = connection.execute(
        """
        SELECT e.event_id, e.aggregate_id, e.payload_json
        FROM platform_events AS e
        LEFT JOIN event_consumer_receipts AS r
          ON r.event_id = e.event_id
         AND r.consumer_name = ?
        WHERE e.event_type IN ('OpportunityCreated', 'OpportunityUpdated')
          AND r.id IS NULL
        ORDER BY e.id
        """,
        (CONSUMER_NAME,),
    ).fetchall()

    created = 0
    skipped = 0
    published = 0

    for event in events:
        payload = json.loads(event["payload_json"])
        metrics = metrics_from_payload(payload)
        if not metrics["opportunity_id"]:
            metrics["opportunity_id"] = str(event["aggregate_id"])

        if not should_review(metrics):
            connection.execute(
                """
                INSERT OR IGNORE INTO event_consumer_receipts
                    (consumer_name, event_id, result_json)
                VALUES (?, ?, ?)
                """,
                (CONSUMER_NAME, event["event_id"], json.dumps({"status": "SKIPPED"})),
            )
            skipped += 1
            continue

        confidence_score, confidence_label = confidence(metrics)
        risk_level, risk_reasons = risk(metrics)
        next_action = recommendation(metrics["decision"])
        review_id = str(uuid.uuid4())
        review_hash = fingerprint(event["event_id"], metrics)
        market_name = metrics["title"] or metrics["market_id"] or "Unknown market"
        outcome_name = metrics["outcome"] or "Unknown outcome"
        summary = (
            f"{market_name} | {outcome_name}: score {metrics['score']:.2f}, "
            f"confidence {confidence_label}, recommendation {next_action}."
        )
        reasoning = [
            f"Opportunity decision is {metrics['decision'] or 'UNSPECIFIED'}.",
            f"Opportunity score is {metrics['score']:.2f}.",
            f"Wallet count is {metrics['wallet_count']}.",
            f"Elite wallet count is {metrics['elite_wallet_count']}.",
            f"Observed supporting capital is ${metrics['capital']:,.2f}.",
        ] + [f"Risk: {item}." for item in risk_reasons]

        cursor = connection.execute(
            """
            INSERT OR IGNORE INTO institutional_reviews (
                review_id, opportunity_id, market_id, source_event_id,
                review_timestamp, review_status, opportunity_score,
                opportunity_grade, opportunity_decision, confidence_score,
                confidence_label, risk_level, recommendation, summary,
                reasoning_json, metrics_json, review_fingerprint, engine_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                review_id,
                metrics["opportunity_id"],
                metrics["market_id"],
                event["event_id"],
                utc_now(),
                "COMPLETED",
                metrics["score"],
                metrics["grade"],
                metrics["decision"],
                confidence_score,
                confidence_label,
                risk_level,
                next_action,
                summary,
                json.dumps(reasoning, sort_keys=True),
                json.dumps(metrics, sort_keys=True),
                review_hash,
                ENGINE_VERSION,
            ),
        )

        if cursor.rowcount == 1:
            created += 1
            event_cursor = connection.execute(
                """
                INSERT OR IGNORE INTO platform_events (
                    event_id, event_type, source_engine, source_version,
                    aggregate_type, aggregate_id, payload_json, occurred_at,
                    correlation_id, causation_id, deduplication_key, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(uuid.uuid4()),
                    "OpportunityReviewed",
                    CONSUMER_NAME,
                    ENGINE_VERSION,
                    "institutional_review",
                    review_id,
                    json.dumps({
                        "review_id": review_id,
                        "opportunity_id": metrics["opportunity_id"],
                        "market_id": metrics["market_id"],
                        "confidence_score": confidence_score,
                        "confidence_label": confidence_label,
                        "risk_level": risk_level,
                        "recommendation": next_action,
                        "summary": summary,
                    }, sort_keys=True),
                    utc_now(),
                    event["event_id"],
                    event["event_id"],
                    f"OpportunityReviewed:{review_hash}",
                    "PENDING",
                ),
            )
            published += event_cursor.rowcount

        connection.execute(
            """
            INSERT OR IGNORE INTO event_consumer_receipts
                (consumer_name, event_id, result_json)
            VALUES (?, ?, ?)
            """,
            (
                CONSUMER_NAME,
                event["event_id"],
                json.dumps({"status": "REVIEWED", "review_id": review_id}),
            ),
        )

    connection.execute(
        """
        UPDATE event_consumers
        SET last_run_at = CURRENT_TIMESTAMP,
            last_success_at = CURRENT_TIMESTAMP,
            last_error = NULL,
            updated_at = CURRENT_TIMESTAMP
        WHERE consumer_name = ?
        """,
        (CONSUMER_NAME,),
    )
    connection.commit()

    print("=" * 72)
    print("INSTITUTIONAL REVIEW ENGINE")
    print("=" * 72)
    print(f"Source events examined: {len(events):,}")
    print(f"New reviews created: {created:,}")
    print(f"Events skipped: {skipped:,}")
    print(f"OpportunityReviewed events published: {published:,}")
    print("=" * 72)
    connection.close()


if __name__ == "__main__":
    main()
