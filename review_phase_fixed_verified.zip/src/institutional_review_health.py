from __future__ import annotations

import sqlite3
from pathlib import Path

DB_PATH = Path("database") / "polymarket.db"
CONSUMER_NAME = "institutional_review_engine_v1"


def main() -> None:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row

    table_exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='institutional_reviews'"
    ).fetchone() is not None
    view_exists = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='view' AND name='current_institutional_reviews'"
    ).fetchone() is not None

    total_reviews = 0
    duplicate_reviews = 0
    reviewed_events = 0
    pending_reviewed_events = 0

    if table_exists:
        total_reviews = connection.execute(
            "SELECT COUNT(*) AS total FROM institutional_reviews"
        ).fetchone()["total"]
        duplicate_reviews = connection.execute(
            """
            SELECT COUNT(*) AS total
            FROM (
                SELECT review_fingerprint
                FROM institutional_reviews
                GROUP BY review_fingerprint
                HAVING COUNT(*) > 1
            )
            """
        ).fetchone()["total"]

    reviewed_events = connection.execute(
        "SELECT COUNT(*) AS total FROM platform_events WHERE event_type='OpportunityReviewed'"
    ).fetchone()["total"]
    pending_reviewed_events = connection.execute(
        """
        SELECT COUNT(*) AS total
        FROM platform_events
        WHERE event_type='OpportunityReviewed' AND status='PENDING'
        """
    ).fetchone()["total"]

    consumer = connection.execute(
        """
        SELECT last_success_at, last_error
        FROM event_consumers
        WHERE consumer_name = ?
        """,
        (CONSUMER_NAME,),
    ).fetchone()

    healthy = (
        table_exists
        and view_exists
        and duplicate_reviews == 0
        and consumer is not None
        and not consumer["last_error"]
    )

    print("=" * 72)
    print("INSTITUTIONAL REVIEW HEALTH")
    print("=" * 72)
    print(f"institutional_reviews: {'OK' if table_exists else 'MISSING'}")
    print(f"current_institutional_reviews: {'OK' if view_exists else 'MISSING'}")
    print(f"Total reviews: {total_reviews}")
    print(f"OpportunityReviewed events: {reviewed_events}")
    print(f"Pending OpportunityReviewed events: {pending_reviewed_events}")
    print(f"Duplicate review fingerprints: {duplicate_reviews}")
    print(f"Consumer registered: {'YES' if consumer else 'NO'}")
    if consumer:
        print(f"Last successful run: {consumer['last_success_at']}")
        print(f"Last error: {consumer['last_error']}")
    print(f"Overall status: {'HEALTHY' if healthy else 'ATTENTION REQUIRED'}")
    print("=" * 72)

    connection.close()
    if not healthy:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
