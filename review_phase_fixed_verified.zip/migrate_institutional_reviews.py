from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

ROOT = Path.cwd()
DB_PATH = ROOT / "database" / "polymarket.db"
BACKUP_DIR = ROOT / "database" / "backups"


def main() -> None:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = BACKUP_DIR / f"polymarket_before_institutional_reviews_{stamp}.db"
    shutil.copy2(DB_PATH, backup)

    connection = sqlite3.connect(DB_PATH)
    try:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS institutional_reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                review_id TEXT NOT NULL UNIQUE,
                opportunity_id TEXT NOT NULL,
                market_id TEXT,
                source_event_id TEXT NOT NULL,
                review_timestamp TEXT NOT NULL,
                review_status TEXT NOT NULL,
                opportunity_score REAL,
                opportunity_grade TEXT,
                opportunity_decision TEXT,
                confidence_score REAL NOT NULL,
                confidence_label TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                recommendation TEXT NOT NULL,
                summary TEXT NOT NULL,
                reasoning_json TEXT NOT NULL,
                metrics_json TEXT NOT NULL,
                review_fingerprint TEXT NOT NULL UNIQUE,
                engine_version TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE INDEX IF NOT EXISTS idx_institutional_reviews_opportunity
                ON institutional_reviews(opportunity_id, id DESC);

            CREATE INDEX IF NOT EXISTS idx_institutional_reviews_recommendation
                ON institutional_reviews(recommendation, confidence_score DESC);

            DROP VIEW IF EXISTS current_institutional_reviews;

            CREATE VIEW current_institutional_reviews AS
            SELECT r.*
            FROM institutional_reviews AS r
            JOIN (
                SELECT opportunity_id, MAX(id) AS latest_id
                FROM institutional_reviews
                GROUP BY opportunity_id
            ) AS latest
              ON latest.latest_id = r.id;
            """
        )
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()

    print("=" * 72)
    print("INSTITUTIONAL REVIEW MIGRATION COMPLETE")
    print("=" * 72)
    print(f"Backup: {backup}")
    print("Table: institutional_reviews")
    print("View: current_institutional_reviews")
    print("=" * 72)


if __name__ == "__main__":
    main()
